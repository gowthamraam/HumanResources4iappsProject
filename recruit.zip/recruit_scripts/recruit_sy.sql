create synonym xxhlp_applicants for xxhlp.xxhlp_applicants;
create synonym xxhlp_app_educations for xxhlp.xxhlp_app_educations;
create synonym xxhlp_app_employments for xxhlp.xxhlp_app_employments;
create synonym xxhlp_app_interviews for xxhlp.xxhlp_app_interviews;
create synonym xxhlp_app_int_panels for xxhlp.xxhlp_app_int_panels;

create synonym xxhlp_app_id_s for xxhlp.xxhlp_app_id_s;
create synonym xxhlp_app_edu_id_s for xxhlp.xxhlp_app_edu_id_s;
create synonym xxhlp_app_emp_id_s for xxhlp.xxhlp_app_emp_id_s;
create synonym xxhlp_app_int_id_s for xxhlp.xxhlp_app_int_id_s;
create synonym xxhlp_int_panel_id_s for xxhlp.xxhlp_int_panel_id_s;
